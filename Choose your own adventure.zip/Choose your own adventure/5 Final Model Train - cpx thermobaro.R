###############################
#### MAKE THE ACTUAL MODEL ####
###############################
library(PerformanceAnalytics)
library(rJava)
options(java.parameters = "-Xmx4g") #Note: you must run this at the beginning of you session otherwise it'll suck
library(extraTrees)

setwd(paste(dirname(rstudioapi::getActiveDocumentContext()$path)))

options(scipen = 999)
'%!in%' <- function(x,y)!('%in%'(x,y))

######### READ DATA AND REMOVE FILTERED EXPERIMENTS #######
#Load raw data 
load("input.Rdata")

#### What do you have? ####
#SAME AS #4 or else the SEE you calculated is incorrect!
liq <- c("NoLiquid") #OR Liquid

#Set the oxides
ox <- c("SiO2", "TiO2","Al2O3", "Cr2O3","FeO","MgO", "MnO", "CaO", "Na2O") #Make sure this order stays the same!!
liqox <- c("SiO2", "TiO2","Al2O3", "FeO","MgO", "MnO", "CaO", "Na2O","K2O")
var <- paste0(ox,".cpx") #adds .cpx to the cpx oxides
if(liq == "Liquid") {var <- c(var, paste0(liqox,".liq"))} #adds .liq to the liquid variables

#Hyperparamters
r <- 200                #Number of test/train splits
n.cuts <- 1             #number of random cuts
n.tree <- 201           #number of trees 
m.try <-length(var)*2/3 #this should be 12 for liquid and 6 for no liquid.

dat <- input

##If you want to filter for pressure do it here
# atm <- c("1atm.Exc")   #if you want to exclude the 1 atm experiments you can
# cm <- c("Crust")      #if you only want 0-15 kbar experiments
# p.lower <- 0
# p.upper <- 50
# if(atm == "1atm.Exc") {p.lower <- 0.01}
# if(cm == "Crust") {p.upper <- 15} #you can change this if you want, but make sure you change it in #5 as well
# dat <- input[which(input$P >= p.lower & input$P <= p.upper),]

#Train pressure model
P_C_noliq <- extraTrees(x = dat[, var], y = dat$P, ntree = n.tree, mtry = m.try, numRandomCuts = n.cuts, numThreads = 8)

#Train temperature model
T_C_noliq <- extraTrees(x = dat[, var], y = dat$T, ntree = n.tree, mtry = m.try, numRandomCuts = n.cuts, numThreads = 8)

#Save models
prepareForSave(P_C_noliq)
save(P_C_noliq, file = "P_C_noliq.Rdata")
prepareForSave(T_C_noliq)
save(T_C_noliq, file = "T_C_noliq.Rdata")

