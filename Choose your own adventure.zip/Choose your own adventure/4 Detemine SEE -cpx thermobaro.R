######################
#### DETERMINE SEE####
######################
#we recommend cleaning the global environment before running this code, sometimes if you don't you will get an error with the "times" argument at the end

library(PerformanceAnalytics)
library(rJava)
options(java.parameters = "-Xmx4g") #Note: you must run this at the beginning of you session otherwise you may run into problems
library(extraTrees)

setwd(paste(dirname(rstudioapi::getActiveDocumentContext()$path)))

options(scipen = 999)
'%!in%' <- function(x,y)!('%in%'(x,y))

######### READ DATA AND REMOVE FILTERED EXPERIMENTS #######
#Load raw data 
load("input.Rdata")

##### LOAD IN TEST AND TRAIN IDS
load("testids.Rdata")
load("trainids.Rdata")

#### What do you have? ####
#YOU DECIDE#
liq <- c("NoLiquid") #OR NoLiquid

#Set the oxides
ox <- c("SiO2", "TiO2","Al2O3", "Cr2O3","FeO","MgO", "MnO", "CaO", "Na2O")
liqox <- c("SiO2", "TiO2","Al2O3", "FeO","MgO", "MnO", "CaO", "Na2O","K2O")
var <- paste0(ox,".cpx") #adds .cpx to the cpx oxides
if(liq == "Liquid") {var <- c(var, paste0(liqox,".liq"))} #adds .liq to the liquid variables

#Hyperparamters
r <- 200                #Number of test/train splits
n.cuts <- 1             #number of random cuts
n.tree <- 201           #number of trees 
m.try <-length(var)*2/3 #this should be 12 for liquid and 6 for no liquid.

dat <- input

##If you want to filter for pressure do it here
# atm <- c("1atm.Exc")   #if you want to exclude the 1 atm experiments you can
# cm <- c("Crust")      #if you only want 0-15 kbar experiments
# p.lower <- 0
# p.upper <- 50
# if(atm == "1atm.Exc") {p.lower <- 0.01}
# if(cm == "Crust") {p.upper <- 15} #you can change this if you want, but make sure you change it in #5 as well
# dat <- input[which(input$P >= p.lower & input$P <= p.upper),]


###### SUBSET THE IDS ####
dat.ids <- as.numeric(rownames(dat))
id.test <- lapply(1:r, function(x) {which(dat.ids %in% test.ids[[x]])})
id.train <- lapply(1:r, function(x) {which(dat.ids %in% train.ids[[x]])})

##### Make empty lists to save the data ####
output  <- list()
Pred_P  <- list()
Mode_P  <- list()
Resid_P <- list()
SEE_P   <- list()
R2_P    <- list()
Pred_T  <- list()
Mode_T  <- list()
Resid_T <- list()
SEE_T   <- list()
R2_T    <- list()

##### TRAIN MODELS ####
for(j in 1:r) {
  
##PRESSURE##
#train the model, this is done for 200 (r) times
model_P <- extraTrees(x = dat[id.train[[j]], var], y = dat$P[id.train[[j]]], ntree = n.tree, mtry = m.try, numRandomCuts = n.cuts, numThreads = 8) ; print(j)

Pred_P[[j]] <- (predict(model_P, newdata = dat[id.test[[j]], var],allValues = TRUE)) #Predict the pressure in the testset, with all trees
unlP = as.data.frame(Pred_P[[j]])           #turn Pred_P into a dataframe
mo_P <- list()                              #make an empty list
for (k in 1:(lengths(id.test)[j])){         #this loop determines the modal pressure
  dens_P <- density(as.numeric(unlP[k,]))
  mo_P[k] <- dens_P$x[which.max(dens_P$y)]
  }
Mode_P[[j]] <- mo_P                         #saves the modal pressures in a list
Resid_P[[j]] <- dat$P[id.test[[j]]]- unlist(Mode_P[[j]])   #Calculate the residual for each estimate
SEE_P[[j]] <- round((sum((unlist(Mode_P[[j]])-dat$P[id.test[[j]]])^2)/length(dat$P[id.test[[j]]]))^(0.5), digits = 2) #Calculates SEE for each 200 (r) test/train split
R2_P[[j]] <- round(summary(lm(unlist(Mode_P[[j]])~dat$P[id.test[[j]]]))$r.squared, digits = 3)  #Calculates the R squared for each of the 200 (r) test/train splits


#TEMPERATURE > same process as the pressure
model_T <- extraTrees(x = dat[id.train[[j]], var], y = dat$T[id.train[[j]]], ntree = n.tree, mtry = m.try, numRandomCuts = n.cuts, numThreads = 8) ; print(j)

Pred_T[[j]] <- (predict(model_T, newdata = dat[id.test[[j]], var],allValues = TRUE))
unlT = as.data.frame(Pred_T[[j]])
mo_T <- list()
for (k in 1:(lengths(id.test)[j])){
  dens_T <- density(as.numeric(unlT[k,]))
  mo_T[k] <- dens_T$x[which.max(dens_T$y)]
  }
Mode_T[[j]] <- mo_T
Resid_T[[j]] <- dat$T[id.test[[j]]]- unlist(Mode_T[[j]])
SEE_T[[j]] <- round((sum((unlist(Mode_T[[j]])-dat$T[id.test[[j]]])^2)/length(dat$T[id.test[[j]]]))^(0.5), digits = 2)
R2_T[[j]] <- round(summary(lm(unlist(Mode_T[[j]])~dat$T[id.test[[j]]]))$r.squared, digits = 3)
}

#### SAVE ALL DATA TO OUTPUT #####
output <- dat[unlist(id.test),]
output$r <- rep(1:r, times = lapply(id.test, length))
#Add pressure data
output$Pred.P <- unlist(Mode_P)
output$Resid.P<- unlist(Resid_P)
output$SEE.P  <- rep(unlist(SEE_P), times = lapply(id.test, length))
output$R2.P   <- rep(unlist(R2_P), times = lapply(id.test, length))
#Add temperature data
output$Pred.T <- unlist(Mode_T)
output$Resid.T<- unlist(Resid_T)
output$SEE.T  <- rep(unlist(SEE_T), times = lapply(id.test, length))
output$R2.T   <- rep(unlist(R2_T), times = lapply(id.test, length))

#take the modes of 200 SEEs 
hist(output$SEE.P)
print(density(output$SEE.P)$x[which.max(density(output$SEE.P)$y)])

hist(output$SEE.T)
print(density(output$SEE.T)$x[which.max(density(output$SEE.T)$y)])

##### SAVE AND EXPORT ####
final <- Reduce(rbind, output)
save(final, file = "final.Rdata")






