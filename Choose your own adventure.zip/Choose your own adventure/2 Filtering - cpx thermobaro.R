###### Filtering #####
######################
#Here we filter on the basis of Kd and cations
#we also filter for reasonable SiO2 and P ranges with enough datapoints (currently max 50 kbar)
#this spits out a file called input - this is what the calibration dataset will be
######################
library(readxl)

setwd(paste(dirname(rstudioapi::getActiveDocumentContext()$path)))

#Load all data
load("raw.Rdata")
dat <- raw

#Make a final input.cats dataframe on which to perform the filtering
cats <- dat[,paste0(c("Si", "Al", "Ti", "Ca", "Na", "K", "Fe", "Mg", "Mn", "Cr", "Ni", "P"), ".cpx")]

#Make a column to decide if the experiment should be removed or not
dat$Rm <- "N"

#Remove obviously bad experiments. These should never be added to the model because they are poor
dat$Rm[which(is.na(apply(cats, 1, sum)))] <- "Y"
dat$Rm[which(apply(cats, 1, sum) > 4.04 | apply(cats, 1, sum) < 3.96)] <- "Y"

#Add a kd filter
upper.kd <- 0.68
lower.kd <- 0.04

dat$kd <- (dat$FeO.cpx/dat$MgO.cpx) / (dat$FeO.liq/dat$MgO.liq)
dat$Rm[which(is.na(dat$kd) == TRUE)] <- "Y"
dat$Rm[which(dat$kd > upper.kd | dat$kd < lower.kd)] <- "Y"

#Remove experiments that we decide are too deep for either crustal or mantle models
max.p <- 50
dat$Rm[which(dat$P > max.p)] <- "Y"

#Remove extremly low SiO2 liquids
dat$Rm[which(dat$SiO2.liq < 35)] <- "Y"

#Remove experiments and set final file for input
input <- dat[which(dat$Rm == "N"),]

#Mix data (to avoid the bias linked to the organisation of the data with the most recent at the end of the matrix)
input<- input[sample(seq(1,nrow(input),1), nrow(input)),]
rownames(input) <- NULL

save(input, file = "input.Rdata")

