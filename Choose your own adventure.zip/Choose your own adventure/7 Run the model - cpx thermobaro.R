########################
#####Run the model######
########################
#Load your data in! The SEE for this is what you calculated in #4
#######################
library(PerformanceAnalytics)
library(rJava)
options(java.parameters = "-Xmx4g") #Note: you must run this at the beginning of you session otherwise it'll suck
library(extraTrees)
library(readxl)
library(EnvStats)

setwd(paste(dirname(rstudioapi::getActiveDocumentContext()$path)))
####load models####
load("P_C.Rdata")
load("T_C.Rdata")
load("YOURDATA.Rdata")
####Load in your data####
#Filter your data using sheet 1 and 2 before this step. 
INPUTDATA <- YOURDATA[,c("SiO2.cpx","TiO2.cpx","Al2O3.cpx","Cr2O3.cpx","FeO.cpx","MgO.cpx","MnO.cpx","CaO.cpx","Na2O.cpx")] #make sure the elements are the same and they have the same naming convention 
   #if you have liquids use this instead
   #INPUTDATA <- YOURDATA[,c("SiO2.cpx","TiO2.cpx","Al2O3.cpx","Cr2O3.cpx","FeO.cpx","MgO.cpx","MnO.cpx","CaO.cpx","Na2O.cpx","SiO2.liq", "TiO2.liq","Al2O3.liq", "FeO.liq","MgO.liq", "MnO.liq", "CaO.liq", "Na2O.liq","K2O.liq")]  

####Run the models ####
predP <- predict(P_C, newdata = INPUTDATA, allValues=TRUE) #this applies the model to your data 
predT <- predict(T_C, newdata = INPUTDATA, allValues=TRUE) #this applies the model to your data 

P_values = data.frame(1:nrow(predP))
T_values = data.frame(1:nrow(predT))
for (i in 1:nrow(predP)){
   P_values$pred_P[i]       = median(predP[i,])
   P_values$P.IQR[i]        = iqr(predP[i,])
   T_values$pred_T[i]       = median(predT[i,])
   T_values$T.IQR[i]        = iqr(predT[i,])
   }


PT_values = cbind(P_values, T_values)
YOURDATA_PT = cbind(YOURDATA, PT_values) #this adds  the estimates to your data 
write.csv(YOURDATA_PT,'YOURDATA_PT.csv') #save it! :)
#P out outputs are in kbar, T outputs are in celsius

hist(PT_values$pred_P)
hist(PT_values$pred_T)

